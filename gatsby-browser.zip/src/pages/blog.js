import React from "react"
import { graphql, Link } from "gatsby"

const Blog = ({ data }) => {
  const allBlog = data.allWpPost
  console.log(allBlog);

  return (
    <div>
      <div>{allBlog.nodes[0].title}</div>
      {
        allBlog.nodes.map((blogP, index) => (
          <div key={index}>
            <Link to={blogP.slug}>
              <p>{blogP.title}</p>
            </Link>
            <div dangerouslySetInnerHTML={{ __html: blogP.excerpt }} />
          </div>
        ))
      }
    </div>
  )
}

export const query = graphql`
  {
    allWpPost {
      nodes {
        excerpt
        id
        uri
        title
        slug
      }
    }
  }
`

export default Blog;

