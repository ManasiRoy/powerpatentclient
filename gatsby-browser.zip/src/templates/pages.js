import React from "react"
import { graphql } from "gatsby"

const Pages = ({ data }) => <pre>{JSON.stringify(data, null, 4)}</pre>

export const query = graphql`
  {
    wpgraphql {
      pages {
        nodes {
          id
          title
          uri
          content
        }
      }
    }
  }
`

export default Pages
